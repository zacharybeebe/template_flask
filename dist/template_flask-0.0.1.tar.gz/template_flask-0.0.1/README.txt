# bfs (Basic Flask Setup)

from the command line navigate to the directory where you would like to keep your project

type "python -m bfs" and click enter

enter the name of your project

once completed you will have a basic flask directory structure setup and a virtual environment with these packages installed within it...
atomicwrites
attrs
blinker
click
colorama
coverage
Flask
Flask-DebugToolbar
Flask-Login
Flask-Mail
Flask-SQLAlchemy
Flask-WTF
greenlet
importlib-metadata
iniconfig
itsdangerous
Jinja2
MarkupSafe
packaging
pluggy
py
pyparsing
pytest
pytest-cov
SQLAlchemy
toml
typing-extensions
Werkzeug
WTForms
zipp

		


